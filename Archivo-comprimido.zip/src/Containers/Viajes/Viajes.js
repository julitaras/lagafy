import React, { useState, useEffect } from 'react';
import List from '../../Components/List/List';

const Viajes = (props) => {
  const [Lists,setLists] = useState([])
  
  let getLists = async () => {
    var requestOptions = {
      method: 'GET',
      redirect: 'follow',
      mode: 'no-cors'
    };
    
    return  await fetch("http://localhost:8080/api/travels?Authorization=Bearer acb", requestOptions)
      .then(res => {return res})
      .catch(error => console.log('error', error));
  }

  useEffect (()=>{
    getLists();
  },[])

  return (
      <div>
        {Lists.forEach((element,i) => {
          return (<List elements={element} ></List>)
        })}
      </div>
    
  );
}

export default Viajes;