module.exports = {
    appId: 'a23be411-98bb-438b-a66f-0dc4d90e2443',
    redirectUri: 'http://localhost:3000',
    scopes: [
      'user.read',
      'calendars.read'
    ]
  };