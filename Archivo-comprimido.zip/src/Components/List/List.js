import React from 'react';
import { ListGroup, ListGroupItem } from 'reactstrap';

const List = (props) => {
  return (
    <ListGroup>
      props.elements.forEach(el => {
        <ListGroupItem>el.displayName</ListGroupItem>
      });
    </ListGroup>
  );
}

export default List;